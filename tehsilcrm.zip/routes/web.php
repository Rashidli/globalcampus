<?php

use App\Http\Controllers\AgentController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;


Route::get('/login', [AuthController::class,'login'])->name('login');
Route::post('/login_submit',[AuthController::class,'login_submit'])->name('login_submit');

Route::group(['middleware' =>'auth'], function (){

    Route::get('/', [AuthController::class,'home'])->name('home');
    Route::get('/logout',[AuthController::class,'logout'])->name('logout');
    Route::resource('users',UserController::class);
    Route::resource('agents',AgentController::class);
    Route::resource('roles',RoleController::class);
    Route::resource('permissions',PermissionController::class);
    Route::resource('students',StudentController::class);

});

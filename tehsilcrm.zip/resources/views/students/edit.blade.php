@extends('layouts.master')
@section('title', 'Tələbələr')
<style>
    .success-message {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
        border-radius: 5px;
        padding: 15px;
        margin: 10px 0;
        font-family: Arial, sans-serif;
        font-size: 16px;
    }

</style>
@section('content')
    <a href="{{route('students.index')}}" class="goBack">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M10.0303 6.46967C10.3232 6.76256 10.3232 7.23744 10.0303 7.53033L6.31066 11.25L14.5 11.25C15.4534 11.25 16.8667 11.5298 18.0632 12.3913C19.298 13.2804 20.25 14.7556 20.25 17C20.25 17.4142 19.9142 17.75 19.5 17.75C19.0858 17.75 18.75 17.4142 18.75 17C18.75 15.2444 18.0353 14.2196 17.1868 13.6087C16.3 12.9702 15.2133 12.75 14.5 12.75L6.31066 12.75L10.0303 16.4697C10.3232 16.7626 10.3232 17.2374 10.0303 17.5303C9.73744 17.8232 9.26256 17.8232 8.96967 17.5303L3.96967 12.5303C3.67678 12.2374 3.67678 11.7626 3.96967 11.4697L8.96967 6.46967C9.26256 6.17678 9.73744 6.17678 10.0303 6.46967Z" fill="black"/>
        </svg>
        Geri
    </a>
    <div class="addNewStudent-container">
        <h2>Məlumatları düzəliş et</h2>
        <form action="" class="addNewStudentForm" method="post">
            <div class="personalInfoForm">
                <div class="formTitle">
                    <span>01</span>
                    <h3>Şəxsi məlumatlar</h3>
                </div>
                <div class="form-items">
                    <div class="form-item">
                        <label for="">Ad<sup>*</sup></label>
                        <input type="text" name="name" value="{{$user->name}}" placeholder="Ad">
                        @if($errors->first('name'))<small class="form-text text-danger">{{$errors->first('name')}}</small>@endif

                    </div>
                    <div class="form-item">
                        <label for="">Soyad<sup>*</sup></label>
                        <input type="text" name="surname" value="{{$user->surname}}" placeholder="Soyad">
                        @if($errors->first('surname'))<small class="form-text text-danger">{{$errors->first('surname')}}</small>@endif
                    </div>
                    <div class="form-item">
                        <label for="">Ata adı<sup>*</sup></label>
                        <input type="text" name="father_name" value="{{$user->father_name}}" placeholder="Ata adı">
                        @if($errors->first('father_name'))<small class="form-text text-danger">{{$errors->first('father_name')}}</small>@endif
                    </div>
                    <div class="form-item">
                        <label for="">Doğum tarixi<sup>*</sup></label>
                        <input type="date" name="birthday" value="{{$user->birthday}}" class="datepicker" placeholder="Gün/Ay/İl">
                        @if($errors->first('birthday'))<small class="form-text text-danger">{{$errors->first('birthday')}}</small>@endif
                    </div>
                    <div class="form-item">
                        <label for="">Email<sup>*</sup></label>
                        <input type="email" name="contact_email" value="{{$user->contact_email}}" placeholder="Email">
                        @if($errors->first('contact_email'))<small class="form-text text-danger">{{$errors->first('contact_email')}}</small>@endif
                    </div>
                    <div class="form-item">
                        <label for="">Mobil nömrə<sup>*</sup></label>
                        <input type="text" name="phone" value="{{$user->phone}}" placeholder="+994 50 000 00 00">
                        @if($errors->first('phone'))<small class="form-text text-danger">{{$errors->first('phone')}}</small>@endif
                    </div>
                    <div class="form-item">
                        <label for="">Qeydiyyatda olduğu ünvan</label>
                        <input type="text" placeholder="Ünvan" name="address" value="{{$user->address}}">
                        @if($errors->first('address'))<small class="form-text text-danger">{{$errors->first('address')}}</small>@endif
                    </div>
                    <div class="form-item">
                        <label>Ailə vəziyyəti<sup>*</sup></label>
                        <div class="form-checks">
                            <div class="form-check-item">
                                <div class="custom-checkbox">
                                    <input type="radio" id="student_single" value="Subay"
                                           {{$user->marital_status == 'Subay' ? 'checked' : ''}} name="marital_status" />
                                    <label for="student_single"></label>
                                </div>
                                <label for="student_single">Subay</label>
                            </div>
                            <div class="form-check-item">
                                <div class="custom-checkbox">
                                    <input type="radio" id="student_married" value="Evli"
                                           {{$user->marital_status == 'Evli' ? 'checked' : ''}} name="marital_status" />
                                    <label for="student_married"></label>
                                </div>
                                <label for="student_married">Evli</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-item">
                        <label>Cins<sup>*</sup></label>
                        <div class="form-checks">
                            <div class="form-check-item">
                                <div class="custom-checkbox">
                                    <input type="radio" id="qadin" value="Qadın" name="gender"
                                        {{$user->gender == 'Qadın' ? 'checked' : ''}} />
                                    <label for="qadin"></label>
                                </div>
                                <label for="qadin">Qadın</label>
                            </div>
                            <div class="form-check-item">
                                <div class="custom-checkbox">
                                    <input type="radio" id="kisi" value="Kişi" name="gender"
                                        {{$user->gender == 'Kişi' ? 'checked' : ''}} />
                                    <label for="kisi"></label>
                                </div>
                                <label for="kisi">Kişi</label>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="documentsInfoForm">
                <div class="formTitle">
                    <span>02</span>
                    <h3>Sənədlər</h3>
                </div>
                <div class="documentsFormLine">
                    <div class="form-items">
                        <div class="form-item">
                            <label for="">Təhsil dərəcəsi<sup>*</sup></label>
                            <select name="" id="">
                                <option value="">Bakalavr</option>
                                <option value="">Magistr</option>
                                <option value="">Doktorantura</option>
                            </select>
                        </div>
                        <div class="document-inputs">
                            <div class="document-input-line">
                                <div class="document-input-box">
                                    <div class="document-input-box-top">
                                        <label for="">Sənədin adı <sup>*</sup></label>
                                        <button class="resetDocumentBox" type="button">
                                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M12 4L4 12" stroke="#FF1346" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M4 4L12 12" stroke="#FF1346" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                        </button>
                                    </div>
                                    <div class="document-input-item">
                                        <input type="file">
                                        <p>
                                            <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M6.59792 15.339L13.1736 9.04458C13.9631 8.28886 13.9631 7.0636 13.1736 6.30788C12.3842 5.55217 11.1041 5.55216 10.3146 6.30788L3.78656 12.5567C2.28652 13.9925 2.28652 16.3205 3.78656 17.7564C5.2866 19.1923 7.71864 19.1923 9.21868 17.7564L15.8421 11.4164C18.0526 9.30037 18.0526 5.86964 15.8421 3.75363C13.6315 1.63762 10.0474 1.63762 7.83682 3.75363L2.5 8.86213" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round"/>
                                            </svg>
                                            Fayl seç
                                        </p>
                                        <span class="fileName"></span>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="educationalInfoForm">
                <div class="formTitle">
                    <span>03</span>
                    <h3>Təhsil</h3>
                </div>
                <div class="educationFormLine">
                    @foreach($user->educations ?? [] as $education)
                        <div class="form-items">
                            <div class="form-item">
                                <label for="">Təhsil müəssisəsi<sup>*</sup></label>
                                <input type="text" value="{{$education->university}}" name="university[]" placeholder="Məktəb, Peşə, Universitet">
                            </div>
                            <div class="form-item">
                                <label for="">Başlama tarixi<sup>*</sup></label>
                                <input type="date" value="{{$education->university_start_date}}" name="start_date[]" placeholder="Ay/İl">
                            </div>
                            <div class="form-item">
                                <label for="">Bitmə tarixi<sup>*</sup></label>
                                <input type="date" value="{{$education->university_end_date}}" name="end_date[]" placeholder="Ay/İl">
                            </div>
                        </div>
                        <button type="button" class="deleteInfoForm">
                            <img src="{{ asset('/') }}assets/images/trash.svg" alt="">
                            Sil
                        </button>
                    @endforeach
                </div>
                <button type="button" class="addInfoForm">
                    <img src="{{ asset('/') }}assets/images/plus.svg" alt="">
                    Əlavə et
                </button>
            </div>
            <div class="workExperienceInfoForm">
                <div class="formTitle">
                    <span>04</span>
                    <h3>İş təcrübəsi</h3>
                </div>
                <div class="workExperienceLine">
                    @foreach($user->experiences ?? [] as $experience)
                        <div class="form-items">
                            <div class="form-item-left">
                                <div class="form-item">
                                    <label for="">İş yeri<sup>*</sup></label>
                                    <input type="text" name="experience_company[]" value="{{$experience->experience_company}}" placeholder="Müəssisənin adı">
                                </div>
                                <div class="form-item">
                                    <label for="">Vəzifə<sup>*</sup></label>
                                    <input type="text" name="position[]" value="{{$experience->position}}" placeholder="Vəzifənin  adı">
                                </div>
                            </div>
                            <div class="form-item-right">
                                <div class="form-item">
                                    <label for="">Başlama tarixi<sup>*</sup></label>
                                    <input type="date" name="experience_start_date[]" value="{{$experience->experience_start_date}}" placeholder="Ay/İl">
                                </div>
                                <div class="form-item">
                                    <label for="">Bitmə tarixi<sup>*</sup></label>
                                    <input type="date" name="experience_end_date[]" value="{{$experience->experience_end_date}}" placeholder="Ay/İl">
                                </div>
                            </div>
                        </div>
                        <button class="deleteInfoForm">
                            <img src="{{ asset('/') }}assets/images/trash.svg" alt="">
                            Sil
                        </button>
                    @endforeach

                </div>
                <button class="addInfoForm">
                    <img src="{{ asset('/') }}assets/images/plus.svg" alt="">
                    Əlavə et
                </button>
            </div>
            <div class="languageSkillsInfoForm">
                <div class="formTitle">
                    <span>05</span>
                    <h3>Dil bilikləri</h3>
                </div>
                <div class="languageSkillsLine">
                    @foreach($user->languages ?? [] as $language)
                        <div class="form-items">
                            <div class="form-item">
                                <label for="">Dil<sup>*</sup></label>
                                <select name="language[]" id="">
                                    <option value="">Seçin</option>
                                    <option value="English" {{$language->language == 'English' ? 'selected' : ''}}>English</option>
                                    <option value="Russian" {{$language->language == 'Russian' ? 'selected' : ''}}>Russian</option>
                                    <option value="Spanish" {{$language->language == 'Spanish' ? 'selected' : ''}}>Spanish</option>
                                    <option value="Turkish" {{$language->language == 'Turkish' ? 'selected' : ''}}>Turkish</option>
                                </select>
                            </div>
                            <div class="form-item">
                                <label for="">Bilik səviyyəniz<sup>*</sup></label>
                                <select name="level[]"  id="">
                                    <option value="">Seçin</option>
                                    <option value="Advanced" {{$language->level == 'Advanced' ? 'selected' : ''}}>Advanced</option>
                                    <option value="Intermediate" {{$language->level == 'Intermediate' ? 'selected' : ''}}>Intermediate</option>
                                    <option value="Pre-Intermediate" {{$language->level == 'Pre-Intermediate' ? 'selected' : ''}}>Pre-Intermediate</option>
                                    <option value="Beginner" {{$language->level == 'Beginner' ? 'selected' : ''}}>Beginner</option>
                                </select>
                            </div>
                        </div>
                        <button class="deleteInfoForm">
                            <img src="{{ asset('/') }}assets/images/trash.svg" alt="">
                            Sil
                        </button>
                    @endforeach

                </div>
                <button type="button" class="addInfoForm">
                    <img src="{{ asset('/') }}assets/images/plus.svg" alt="">
                    Əlavə et
                </button>
            </div>
            <div class="programsInfoForm">
                <div class="formTitle">
                    <span>06</span>
                    <h3>Proqram məlumatları</h3>
                </div>
                <div class="programsLine">
                    @foreach($user->programs ?? [] as $program)
                        <div class="form-items">
                            <div class="form-item">
                                <label for="">Proqramı seç<sup>*</sup></label>
                                <select name="program_name[]" >
                                    <option value="">Seçin</option>
                                    <option value="Erasmus" {{$program->program_name == 'Erasmus' ? 'selected' : ''}}>Erasmus</option>
                                    <option value="Erasmus" {{$program->program_name == 'Erasmus' ? 'selected' : ''}}>Erasmus</option>
                                    <option value="Erasmus" {{$program->program_name == 'Erasmus' ? 'selected' : ''}}>Erasmus</option>
                                    <option value="Erasmus" {{$program->program_name == 'Erasmus' ? 'selected' : ''}}>Erasmus</option>
                                </select>
                            </div>
                            <div class="form-items-right">
                                <div class="form-item">
                                    <label for="">Ölkə<sup>*</sup></label>
                                    <select name="country[]" id="">
                                        <option value="">Seçin</option>
                                        <option value="Rusiya" {{$program->country == 'Rusiya' ? 'selected' : ''}}>Rusiya</option>
                                        <option value="İsvecre" {{$program->country == 'Isvecre' ? 'selected' : ''}}>İsvecre</option>
                                        <option value="Turkiye" {{$program->country == 'Turkiye' ? 'selected' : ''}}>Turkiye</option>
                                        <option value="İtaliya" {{$program->country == 'İtaliya' ? 'selected' : ''}}>İtaliya</option>
                                    </select>
                                </div>
                                <div class="form-item">
                                    <label for="">Şəhər<sup>*</sup></label>
                                    <select name="city[]" id="">
                                        <option value="">Seçin</option>
                                        <option value="Moskva" {{$program->city == 'Moskva' ? 'selected' : ''}}>Moskva</option>
                                        <option value="İstanbul" {{$program->city == 'Istanbul' ? 'selected' : ''}}>İstanbul</option>
                                        <option value="Milan" {{$program->city == 'Milan' ? 'selected' : ''}}>Milan</option>
                                        <option value="Zurih" {{$program->city == 'Zurih' ? 'selected' : ''}}>Zurih</option>
                                    </select>
                                </div>
                                <div class="form-item">
                                    <label for="">Müqavilənin başlayacağı tarix<sup>*</sup></label>
                                    <input type="date" name="program_date[]" value="{{$program->program_date}}" placeholder="Gün/Ay/İl" class="datepicker">
                                </div>
                            </div>

                        </div>
                        <button type="button" class="deleteInfoForm">
                            <img src="{{ asset('/') }}assets/images/trash.svg" alt="">
                            Sil
                        </button>
                    @endforeach

                </div>
                <button type="button" class="addInfoForm">
                    <img src="{{ asset('/') }}assets/images/plus.svg" alt="">
                    Əlavə et
                </button>
            </div>
            <div class="agentInfoForm">
                <div class="formTitle">
                    <span>07</span>
                    <h3>Agent</h3>
                </div>
                <div class="agentLine">
                    <div class="form-items">
                        <div class="form-item">
                            <label for="">Agent seç<sup>*</sup></label>
                            <select name="agent_id" id="">
                                <option value="">Seçin</option>
                                @foreach($agents as $agent)
                                    <option value="{{$agent->id}}" {{$agent->id == $user->agent_id ? 'selected' : '' }}>{{$agent->name}}</option>
                                @endforeach
                            </select>
                            @if($errors->first('agent_id'))
                                <small class="form-text text-danger">{{$errors->first('agent_id')}}</small>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <!-- məlumati edit edecek button -->
            <button class="addStudentBtn" type="submit">Düzəliş et</button>
        </form>
    </div>

@endsection



@extends('layouts.master')
@section('title', 'Tələbələr')
<style>
    .success-message {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
        border-radius: 5px;
        padding: 15px;
        margin: 10px 0;
        font-family: Arial, sans-serif;
        font-size: 16px;
    }

</style>
@section('content')


<div class="students-head-buttons">
    <a href="{{route('students.create')}}" class="addNewStudent">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 5V19" stroke="#1661C3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M5 12H19" stroke="#1661C3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        Əlavə et
    </a>
    <button class="printBtn" type="button">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M11.9451 1.25H12.0549C13.4225 1.24998 14.5248 1.24996 15.3918 1.36652C16.2919 1.48754 17.0497 1.74643 17.6517 2.34835C18.3916 3.08833 18.6205 4.07517 18.7012 5.29943C18.9462 5.31578 19.1763 5.33755 19.3918 5.36652C20.2919 5.48754 21.0497 5.74643 21.6517 6.34835C22.2536 6.95027 22.5125 7.70814 22.6335 8.60825C22.75 9.47522 22.75 10.5775 22.75 11.9451V12.0549C22.75 13.4225 22.75 14.5248 22.6335 15.3918C22.5125 16.2919 22.2536 17.0497 21.6517 17.6517C20.9117 18.3916 19.9248 18.6205 18.7006 18.7012C18.6842 18.9462 18.6625 19.1763 18.6335 19.3918C18.5125 20.2919 18.2536 21.0497 17.6517 21.6517C17.0497 22.2536 16.2919 22.5125 15.3918 22.6335C14.5248 22.75 13.4225 22.75 12.0549 22.75H11.9451C10.5775 22.75 9.47522 22.75 8.60825 22.6335C7.70814 22.5125 6.95027 22.2536 6.34835 21.6517C5.74643 21.0497 5.48754 20.2919 5.36652 19.3918C5.33755 19.1763 5.31578 18.9462 5.29942 18.7012C4.07517 18.6205 3.08833 18.3916 2.34835 17.6517C1.74643 17.0497 1.48754 16.2919 1.36652 15.3918C1.24996 14.5248 1.24998 13.4225 1.25 12.0549V11.9451C1.24998 10.5775 1.24996 9.47522 1.36652 8.60825C1.48754 7.70814 1.74643 6.95027 2.34835 6.34835C2.95027 5.74643 3.70814 5.48754 4.60825 5.36652C4.82374 5.33755 5.05377 5.31578 5.29879 5.29943C5.37952 4.07517 5.60837 3.08833 6.34835 2.34835C6.95027 1.74643 7.70814 1.48754 8.60825 1.36652C9.47522 1.24996 10.5775 1.24998 11.9451 1.25ZM6.80714 5.25295C7.16406 5.24999 7.54313 5.24999 7.94512 5.25H16.0549C16.4569 5.24999 16.8359 5.24999 17.1929 5.25295C17.1109 4.23209 16.9265 3.74452 16.591 3.40901C16.3142 3.13225 15.9257 2.9518 15.1919 2.85315C14.4365 2.75159 13.4354 2.75 12 2.75C10.5646 2.75 9.56347 2.75159 8.80812 2.85315C8.07434 2.9518 7.68577 3.13225 7.40901 3.40901C7.0735 3.74452 6.88909 4.23209 6.80714 5.25295ZM5.25294 17.1929C5.24999 16.8359 5.24999 16.4569 5.25 16.0549L5.25 15.75H5C4.58579 15.75 4.25 15.4142 4.25 15C4.25 14.5858 4.58579 14.25 5 14.25H19C19.4142 14.25 19.75 14.5858 19.75 15C19.75 15.4142 19.4142 15.75 19 15.75H18.75V16.0549C18.75 16.4569 18.75 16.8359 18.7471 17.1929C19.7679 17.1109 20.2555 16.9265 20.591 16.591C20.8678 16.3142 21.0482 15.9257 21.1469 15.1919C21.2484 14.4365 21.25 13.4354 21.25 12C21.25 10.5646 21.2484 9.56347 21.1469 8.80812C21.0482 8.07435 20.8678 7.68577 20.591 7.40901C20.3142 7.13225 19.9257 6.9518 19.1919 6.85315C18.4365 6.75159 17.4354 6.75 16 6.75H8C6.56458 6.75 5.56347 6.75159 4.80812 6.85315C4.07435 6.9518 3.68577 7.13225 3.40901 7.40901C3.13225 7.68577 2.9518 8.07435 2.85315 8.80812C2.75159 9.56347 2.75 10.5646 2.75 12C2.75 13.4354 2.75159 14.4365 2.85315 15.1919C2.9518 15.9257 3.13225 16.3142 3.40901 16.591C3.74452 16.9265 4.23209 17.1109 5.25294 17.1929ZM17.25 15.75H6.75V16C6.75 17.4354 6.75159 18.4365 6.85315 19.1919C6.9518 19.9257 7.13225 20.3142 7.40901 20.591C7.68577 20.8678 8.07435 21.0482 8.80812 21.1469C9.56347 21.2484 10.5646 21.25 12 21.25C13.4354 21.25 14.4365 21.2484 15.1919 21.1469C15.9257 21.0482 16.3142 20.8678 16.591 20.591C16.8678 20.3142 17.0482 19.9257 17.1469 19.1919C17.2484 18.4365 17.25 17.4354 17.25 16V15.75ZM5.25 10C5.25 9.58579 5.58579 9.25 6 9.25H9C9.41422 9.25 9.75 9.58579 9.75 10C9.75 10.4142 9.41422 10.75 9 10.75H6C5.58579 10.75 5.25 10.4142 5.25 10Z" fill="black"/>
            <path d="M18 10C18 10.5523 17.5523 11 17 11C16.4477 11 16 10.5523 16 10C16 9.44772 16.4477 9 17 9C17.5523 9 18 9.44772 18 10Z" fill="black"/>
        </svg>
        Çap et
    </button>
</div>
@if(session('message'))
<div class="success-message">
    <p>{{session('message')}}</p>
</div>
@endif
<div class="students-filter">
    <div class="students-filter-head">
        <p>Filterlə:</p>
        <!-- Aşağıdakı input və ya select bir şey dəyişəndə temizle butonuda gorunemelidi :dd, indilik atiram kommente, bi zehmet hell edersen -->
        @if(request()->query())
            <a href="{{route('students.index')}}" class="clearStudentFilter">
                <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M15 5.5L5 15.5" stroke="#1661C3" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M5 5.5L15 15.5" stroke="#1661C3" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Təmizlə
            </a>
        @endif
    </div>
    <form action="{{ route('students.index') }}" method="get">
        <div class="students-filter-items">
            <div class="students-filter-search">
                <button type="submit" class="studentSeacrhBtn" aria-label="Search">
                    <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M9.58329 2.79169C5.55622 2.79169 2.29163 6.05628 2.29163 10.0834C2.29163 14.1104 5.55622 17.375 9.58329 17.375C13.6104 17.375 16.875 14.1104 16.875 10.0834C16.875 6.05628 13.6104 2.79169 9.58329 2.79169ZM1.04163 10.0834C1.04163 5.36592 4.86586 1.54169 9.58329 1.54169C14.3007 1.54169 18.125 5.36592 18.125 10.0834C18.125 14.8008 14.3007 18.625 9.58329 18.625C4.86586 18.625 1.04163 14.8008 1.04163 10.0834ZM16.2247 16.7247C16.4688 16.4807 16.8645 16.4807 17.1086 16.7247L18.7752 18.3914C19.0193 18.6355 19.0193 19.0312 18.7752 19.2753C18.5312 19.5194 18.1354 19.5194 17.8913 19.2753L16.2247 17.6086C15.9806 17.3646 15.9806 16.9688 16.2247 16.7247Z" fill="black"/>
                    </svg>
                </button>
                <input type="text" name="search" value="{{ request()->search }}" placeholder="Axtar" aria-label="Search students">
            </div>
            <div class="students-filter-main">
                <input type="text" name="location" placeholder="Ölkə, şəhər" value="{{ request()->location }}">
                <select name="company" id="company-select" aria-label="Select Company">
                    <option value="Company MMC">Company MMC</option>
                    <option value="Company1 MMC" {{ request()->company == 'Company1 MMC' ? 'selected' : '' }}>Company1 MMC</option>
                    <option value="Company2 MMC" {{ request()->company == 'Company2 MMC' ? 'selected' : '' }}>Company2 MMC</option>
                    <option value="Company3 MMC" {{ request()->company == 'Company3 MMC' ? 'selected' : '' }}>Company3 MMC</option>
                </select>
                <select name="status" onchange="window.location.href = '{{ route('students.index') }}?status=' + this.value" aria-label="Select Status">
                    <option value="active" {{ request()->status == 'active' ? 'selected' : '' }}>Aktiv</option>
                    <option value="deactive" {{ request()->status == 'deactive' ? 'selected' : '' }}>Deaktiv</option>
                    <option value="completed" {{ request()->status == 'completed' ? 'selected' : '' }}>Proses bitib</option>
                    <option value="cancelled" {{ request()->status == 'cancelled' ? 'selected' : '' }}>Viza imtina</option>
                    <option value="accepted" {{ request()->status == 'accepted' ? 'selected' : '' }}>Qəbu olunub</option>
                </select>
            </div>
        </div>
    </form>

</div>
<div class="table-students-container">
    <table>
        <thead>
        <tr>
            <th class="studentFullName">Ad və soyad</th>
            <th class="studentService">Xidmət</th>
            <th class="studentSale">Satış</th>
            <th class="studentCountry">Ölkə, şəhər</th>
            <th class="studentStatus">Status</th>
            <th class="studentOthers">Digər</th>
        </tr>
        </thead>
        <tbody>
        @foreach($users as $user)
            <tr>
                <td class="studentFullName">{{$user->name}} {{$user->surname}}</td>
                <td class="studentService">Amerikada təhsil</td>
                <td class="studentSale">Company MMC</td>
                <td class="studentCountry">Amerika, New York</td>
                <td class="studentStatus active">{{$user->status}}</td>
                <td class="studentOtherButtons">
                    <a href="{{route('students.show', $user->id)}}" class="studentView">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_122_2876)">
                                <path d="M2.72916 12.7464C2.02088 11.8262 1.66675 11.3661 1.66675 9.99998C1.66675 8.63383 2.02088 8.17375 2.72916 7.25359C4.14338 5.41628 6.51518 3.33331 10.0001 3.33331C13.485 3.33331 15.8568 5.41628 17.271 7.25359C17.9793 8.17375 18.3334 8.63383 18.3334 9.99998C18.3334 11.3661 17.9793 11.8262 17.271 12.7464C15.8568 14.5837 13.485 16.6666 10.0001 16.6666C6.51518 16.6666 4.14339 14.5837 2.72916 12.7464Z" stroke="black" stroke-opacity="0.9" stroke-width="1.5"/>
                                <path d="M12.5 10C12.5 11.3807 11.3807 12.5 10 12.5C8.61929 12.5 7.5 11.3807 7.5 10C7.5 8.61929 8.61929 7.5 10 7.5C11.3807 7.5 12.5 8.61929 12.5 10Z" stroke="black" stroke-opacity="0.9" stroke-width="1.5"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_122_2876">
                                    <rect width="20" height="20" fill="white"/>
                                </clipPath>
                            </defs>
                        </svg>
                    </a>
                    <a href="{{route('students.edit', $user->id)}}" class="studentEdit">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M11.7493 1.9926C13.0172 0.724717 15.0728 0.724717 16.3407 1.9926C17.6086 3.26048 17.6086 5.31612 16.3407 6.584L10.0123 12.9123C9.65568 13.269 9.43787 13.4869 9.1951 13.6762C8.90908 13.8993 8.5996 14.0906 8.27214 14.2467C7.99421 14.3791 7.70195 14.4765 7.2234 14.636L4.99619 15.3784L4.46147 15.5566C3.98285 15.7162 3.45516 15.5916 3.09841 15.2349C2.74167 14.8781 2.6171 14.3504 2.77664 13.8718L3.69728 11.1099C3.85677 10.6313 3.95417 10.3391 4.08663 10.0611C4.24269 9.73369 4.43395 9.42421 4.65705 9.13819C4.8464 8.89542 5.06425 8.6776 5.42096 8.32093L11.7493 1.9926ZM4.96736 14.0704L4.26288 13.3659L4.8699 11.5449C5.04664 11.0147 5.11964 10.7991 5.21503 10.5989C5.33203 10.3534 5.47543 10.1214 5.64269 9.90696C5.77906 9.73212 5.93924 9.57042 6.33443 9.17523L11.2436 4.26608C11.4462 4.77441 11.7891 5.38793 12.3672 5.96608C12.9454 6.54423 13.5589 6.88708 14.0672 7.08972L9.15806 11.9989C8.76287 12.3941 8.60117 12.5542 8.42633 12.6906C8.21189 12.8579 7.97987 13.0013 7.73437 13.1183C7.5342 13.2137 7.31862 13.2866 6.78841 13.4634L4.96736 14.0704ZM15.0632 6.09369C14.96 6.07104 14.831 6.03695 14.6843 5.98606C14.281 5.84612 13.7504 5.58151 13.2511 5.0822C12.7518 4.58288 12.4872 4.05232 12.3472 3.64897C12.2963 3.50227 12.2623 3.37325 12.2396 3.27006L12.6332 2.87648C13.4129 2.09676 14.6771 2.09676 15.4568 2.87648C16.2365 3.65621 16.2365 4.92039 15.4568 5.70012L15.0632 6.09369ZM2.70827 18.3334C2.70827 17.9882 2.98809 17.7084 3.33327 17.7084H16.6666V18.9584H3.33327C2.98809 18.9584 2.70827 18.6785 2.70827 18.3334Z" fill="black" fill-opacity="0.9"/>
                        </svg>
                    </a>
                    <form action="{{route('students.destroy', $user->id)}}" method="post">
                        {{ method_field('DELETE') }}
                        @csrf
                        <button onclick="return confirm('Məlumatın silinməyin təsdiqləyin')" class="agentDelete">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M8.23139 3.54163C8.48909 2.81254 9.18445 2.29169 9.99986 2.29169C10.8153 2.29169 11.5106 2.81254 11.7683 3.54163C11.8834 3.86708 12.2404 4.03766 12.5659 3.92263C12.8913 3.8076 13.0619 3.45052 12.9469 3.12507C12.5182 1.91218 11.3615 1.04169 9.99986 1.04169C8.63824 1.04169 7.48154 1.91218 7.05284 3.12507C6.93781 3.45052 7.10839 3.8076 7.43384 3.92263C7.75929 4.03766 8.11636 3.86708 8.23139 3.54163Z"
                                    fill="#FF1346"/>
                                <path
                                    d="M2.2915 5.00002C2.2915 4.65484 2.57133 4.37502 2.9165 4.37502H17.0832C17.4284 4.37502 17.7082 4.65484 17.7082 5.00002C17.7082 5.3452 17.4284 5.62502 17.0832 5.62502H2.9165C2.57133 5.62502 2.2915 5.3452 2.2915 5.00002Z"
                                    fill="#FF1346"/>
                                <path
                                    d="M4.26388 6.45974C4.6083 6.43678 4.90611 6.69736 4.92907 7.04178L5.31236 12.791C5.38724 13.9142 5.4406 14.6958 5.55774 15.2838C5.67136 15.8542 5.82997 16.1561 6.05782 16.3692C6.28566 16.5824 6.59746 16.7206 7.17413 16.796C7.76863 16.8738 8.55197 16.875 9.67767 16.875H10.3221C11.4478 16.875 12.2312 16.8738 12.8257 16.796C13.4023 16.7206 13.7141 16.5824 13.942 16.3692C14.1698 16.1561 14.3284 15.8542 14.4421 15.2838C14.5592 14.6958 14.6126 13.9142 14.6874 12.791L15.0707 7.04178C15.0937 6.69736 15.3915 6.43678 15.7359 6.45974C16.0803 6.4827 16.3409 6.78051 16.318 7.12493L15.9318 12.9181C15.8605 13.987 15.803 14.8504 15.668 15.528C15.5276 16.2324 15.289 16.8208 14.796 17.282C14.303 17.7433 13.7 17.9423 12.9878 18.0354C12.3028 18.125 11.4374 18.125 10.3661 18.125H9.63372C8.5624 18.125 7.69703 18.125 7.012 18.0354C6.29979 17.9423 5.69683 17.7433 5.20384 17.282C4.71084 16.8208 4.47216 16.2324 4.33182 15.528C4.19685 14.8504 4.1393 13.987 4.06805 12.918L3.68184 7.12493C3.65888 6.78051 3.91947 6.4827 4.26388 6.45974Z"
                                    fill="#FF1346"/>
                            </svg>
                        </button>
                    </form>
                </td>
            </tr>
        @endforeach

        </tbody>
    </table>
</div>

<x-pagination :paginator="$users"/>

@endsection



<div class="page-head">
    <h1>@yield('title')</h1>
    <div class="head-userProfile">
        <h2>{{auth()->user()->name}} {{auth()->user()->surname}}</h2>
        <!-- Burada userin ad ve soyadinin ilk herifi olacaq -->
        <p>{{mb_substr(auth()->user()->name, 0, 1)}}{{mb_substr(auth()->user()->surname, 0, 1)}}</p>
    </div>
</div>

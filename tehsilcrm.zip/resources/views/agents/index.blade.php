@extends('layouts.master')
@section('title', 'Agentlər')

@section('content')
    <div class="agents-head">
        <a href="{{route('agents.create')}}" class="addNewAgent">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 5V19" stroke="#1661C3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M5 12H19" stroke="#1661C3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            Əlavə et
        </a>
        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        <form action="{{route('agents.index')}}" method="get">
            <div class="agents-filter-search">
                <button class="agentSeacrhBtn">
                    <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                              d="M9.58329 2.79169C5.55622 2.79169 2.29163 6.05628 2.29163 10.0834C2.29163 14.1104 5.55622 17.375 9.58329 17.375C13.6104 17.375 16.875 14.1104 16.875 10.0834C16.875 6.05628 13.6104 2.79169 9.58329 2.79169ZM1.04163 10.0834C1.04163 5.36592 4.86586 1.54169 9.58329 1.54169C14.3007 1.54169 18.125 5.36592 18.125 10.0834C18.125 14.8008 14.3007 18.625 9.58329 18.625C4.86586 18.625 1.04163 14.8008 1.04163 10.0834ZM16.2247 16.7247C16.4688 16.4807 16.8645 16.4807 17.1086 16.7247L18.7752 18.3914C19.0193 18.6355 19.0193 19.0312 18.7752 19.2753C18.5312 19.5194 18.1354 19.5194 17.8913 19.2753L16.2247 17.6086C15.9806 17.3646 15.9806 16.9688 16.2247 16.7247Z"
                              fill="black"/>
                    </svg>
                </button>

                <input type="text" name="search" value="{{request()->search}}" placeholder="Axtar">

            </div>
        </form>
    </div>

    <div class="table-agents-container">
        <table>
            <thead>
            <tr>
                <th class="agentFullName">Ad və soyad</th>
                <th class="agentMail">Email</th>
                <th class="agentNumber">Mobil nömrə</th>
                <th class="agentOthers">Digər</th>
            </tr>
            </thead>
            <tbody>
            @foreach($users as $user)
                <tr class="tr" data-user-id="{{$user->id}}">
                    <td class="agentFullName">{{$user->name}} {{$user->surname}}</td>
                    <td class="agentMail">{{$user->email}}</td>
                    <td class="agentNumber">{{$user->phone}}</td>
                    <td class="agentOthersButtons">
                        <button class="agentEdit">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                      d="M11.7493 1.9926C13.0172 0.724717 15.0728 0.724717 16.3407 1.9926C17.6086 3.26048 17.6086 5.31612 16.3407 6.584L10.0123 12.9123C9.65568 13.269 9.43787 13.4869 9.1951 13.6762C8.90908 13.8993 8.5996 14.0906 8.27214 14.2467C7.99421 14.3791 7.70195 14.4765 7.2234 14.636L4.99619 15.3784L4.46147 15.5566C3.98285 15.7162 3.45516 15.5916 3.09841 15.2349C2.74167 14.8781 2.6171 14.3504 2.77664 13.8718L3.69728 11.1099C3.85677 10.6313 3.95417 10.3391 4.08663 10.0611C4.24269 9.73369 4.43395 9.42421 4.65705 9.13819C4.8464 8.89542 5.06425 8.6776 5.42096 8.32093L11.7493 1.9926ZM4.96736 14.0704L4.26288 13.3659L4.8699 11.5449C5.04664 11.0147 5.11964 10.7991 5.21503 10.5989C5.33203 10.3534 5.47543 10.1214 5.64269 9.90696C5.77906 9.73212 5.93924 9.57042 6.33443 9.17523L11.2436 4.26608C11.4462 4.77441 11.7891 5.38793 12.3672 5.96608C12.9454 6.54423 13.5589 6.88708 14.0672 7.08972L9.15806 11.9989C8.76287 12.3941 8.60117 12.5542 8.42633 12.6906C8.21189 12.8579 7.97987 13.0013 7.73437 13.1183C7.5342 13.2137 7.31862 13.2866 6.78841 13.4634L4.96736 14.0704ZM15.0632 6.09369C14.96 6.07104 14.831 6.03695 14.6843 5.98606C14.281 5.84612 13.7504 5.58151 13.2511 5.0822C12.7518 4.58288 12.4872 4.05232 12.3472 3.64897C12.2963 3.50227 12.2623 3.37325 12.2396 3.27006L12.6332 2.87648C13.4129 2.09676 14.6771 2.09676 15.4568 2.87648C16.2365 3.65621 16.2365 4.92039 15.4568 5.70012L15.0632 6.09369ZM2.70827 18.3334C2.70827 17.9882 2.98809 17.7084 3.33327 17.7084H16.6666V18.9584H3.33327C2.98809 18.9584 2.70827 18.6785 2.70827 18.3334Z"
                                      fill="black" fill-opacity="0.9"/>
                            </svg>
                        </button>

                        <form action="{{route('agents.destroy', $user->id)}}" method="post">
                            {{ method_field('DELETE') }}
                            @csrf
                            <button onclick="return confirm('Məlumatın silinməyin təsdiqləyin')" class="agentDelete">
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M8.23139 3.54163C8.48909 2.81254 9.18445 2.29169 9.99986 2.29169C10.8153 2.29169 11.5106 2.81254 11.7683 3.54163C11.8834 3.86708 12.2404 4.03766 12.5659 3.92263C12.8913 3.8076 13.0619 3.45052 12.9469 3.12507C12.5182 1.91218 11.3615 1.04169 9.99986 1.04169C8.63824 1.04169 7.48154 1.91218 7.05284 3.12507C6.93781 3.45052 7.10839 3.8076 7.43384 3.92263C7.75929 4.03766 8.11636 3.86708 8.23139 3.54163Z"
                                        fill="#FF1346"/>
                                    <path
                                        d="M2.2915 5.00002C2.2915 4.65484 2.57133 4.37502 2.9165 4.37502H17.0832C17.4284 4.37502 17.7082 4.65484 17.7082 5.00002C17.7082 5.3452 17.4284 5.62502 17.0832 5.62502H2.9165C2.57133 5.62502 2.2915 5.3452 2.2915 5.00002Z"
                                        fill="#FF1346"/>
                                    <path
                                        d="M4.26388 6.45974C4.6083 6.43678 4.90611 6.69736 4.92907 7.04178L5.31236 12.791C5.38724 13.9142 5.4406 14.6958 5.55774 15.2838C5.67136 15.8542 5.82997 16.1561 6.05782 16.3692C6.28566 16.5824 6.59746 16.7206 7.17413 16.796C7.76863 16.8738 8.55197 16.875 9.67767 16.875H10.3221C11.4478 16.875 12.2312 16.8738 12.8257 16.796C13.4023 16.7206 13.7141 16.5824 13.942 16.3692C14.1698 16.1561 14.3284 15.8542 14.4421 15.2838C14.5592 14.6958 14.6126 13.9142 14.6874 12.791L15.0707 7.04178C15.0937 6.69736 15.3915 6.43678 15.7359 6.45974C16.0803 6.4827 16.3409 6.78051 16.318 7.12493L15.9318 12.9181C15.8605 13.987 15.803 14.8504 15.668 15.528C15.5276 16.2324 15.289 16.8208 14.796 17.282C14.303 17.7433 13.7 17.9423 12.9878 18.0354C12.3028 18.125 11.4374 18.125 10.3661 18.125H9.63372C8.5624 18.125 7.69703 18.125 7.012 18.0354C6.29979 17.9423 5.69683 17.7433 5.20384 17.282C4.71084 16.8208 4.47216 16.2324 4.33182 15.528C4.19685 14.8504 4.1393 13.987 4.06805 12.918L3.68184 7.12493C3.65888 6.78051 3.91947 6.4827 4.26388 6.45974Z"
                                        fill="#FF1346"/>
                                </svg>
                            </button>
                        </form>

                    </td>
                </tr>
            @endforeach

            </tbody>
        </table>
    </div>

    <x-pagination :paginator="$users"/>

    <div class="editAgentModal">
        <div class="editAgentModal-box">
            <h2>Agent məlumatları</h2>
            <button class="closeEditAgentModal" type="button">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 6L6 18" stroke="black" stroke-opacity="0.6" stroke-width="1.5" stroke-linecap="round"
                          stroke-linejoin="round"/>
                    <path d="M6 6L18 18" stroke="black" stroke-opacity="0.6" stroke-width="1.5" stroke-linecap="round"
                          stroke-linejoin="round"/>
                </svg>
            </button>
            <form  class="form_editAgentModal">
                <div class="form-items">
                    <div class="form-item">
                        <label for="">Ad<sup>*</sup></label>
                        <input type="text" id="name" name="name" placeholder="Ad">
                        <span class="text-danger error-message"></span>
                    </div>
                    <div class="form-item">
                        <label for="">Soyad<sup>*</sup></label>
                        <input type="text" id="surname" name="surname" placeholder="Soyad">
                        <span class="text-danger error-message"></span>
                    </div>
                    <div class="form-item">
                        <label for="">Mobil nömrə<sup>*</sup></label>
                        <input type="text" id="phone" name="phone" placeholder="+994 00 000 00 00">
                        <span class="text-danger error-message"></span>
                    </div>
                    <div class="form-item">
                        <label for="">Email<sup>*</sup></label>
                        <input type="email" id="email" name="email" placeholder="Email">
                        <span class="text-danger error-message"></span>
                    </div>
                </div>
                <button class="updatePassBtnText" type="button">Şifrəni yenilə</button>
                <div class="changesAgentPass">
                    <div class="form-item">
                        <label for="">Yeni şifrə<sup>*</sup></label>
                        <div class="password">
                            <input type="password" id="new_password" name="new_password" placeholder="Yeni şifrə">
                            <button class="show_password_btn" type="button">
                                <svg class="show-eye" width="20" height="20" viewBox="0 0 20 20" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M2.72843 12.7464C2.02015 11.8262 1.66602 11.3661 1.66602 9.99999C1.66602 8.63385 2.02015 8.17377 2.72843 7.2536C4.14265 5.41629 6.51444 3.33333 9.99935 3.33333C13.4843 3.33333 15.856 5.41629 17.2703 7.2536C17.9785 8.17377 18.3327 8.63385 18.3327 9.99999C18.3327 11.3661 17.9785 11.8262 17.2703 12.7464C15.856 14.5837 13.4843 16.6667 9.99935 16.6667C6.51444 16.6667 4.14265 14.5837 2.72843 12.7464Z"
                                        stroke="#000" stroke-width="1.5"></path>
                                    <path
                                        d="M12.5 10C12.5 11.3807 11.3807 12.5 10 12.5C8.61929 12.5 7.5 11.3807 7.5 10C7.5 8.61929 8.61929 7.5 10 7.5C11.3807 7.5 12.5 8.61929 12.5 10Z"
                                        stroke="#000" stroke-width="1.5"></path>
                                </svg>
                                <svg class="hidden-eye" width="24" height="24" viewBox="0 0 24 24" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                          d="M22.2954 6.31065C22.6761 6.47382 22.8524 6.91473 22.6893 7.29545L21.9999 7.00001C22.6893 7.29545 22.6894 7.29527 22.6893 7.29545L22.6886 7.29713L22.6875 7.29961L22.6843 7.30697L22.6736 7.33105C22.6646 7.35118 22.6518 7.3794 22.6352 7.41508C22.6019 7.48643 22.5533 7.58776 22.4888 7.71416C22.3599 7.96681 22.1675 8.32069 21.9084 8.73647C21.4828 9.41951 20.8724 10.2777 20.0619 11.1302L21.0303 12.0985C21.3231 12.3914 21.3231 12.8663 21.0303 13.1592C20.7374 13.4521 20.2625 13.4521 19.9696 13.1592L18.969 12.1586C18.3093 12.7113 17.5528 13.23 16.695 13.6562L17.6286 15.091C17.8545 15.4382 17.7562 15.9027 17.409 16.1286C17.0618 16.3546 16.5972 16.2562 16.3713 15.909L15.2821 14.2352C14.5028 14.4897 13.659 14.6626 12.7499 14.7246V16.5C12.7499 16.9142 12.4141 17.25 11.9999 17.25C11.5857 17.25 11.2499 16.9142 11.2499 16.5V14.7246C10.3689 14.6645 9.54909 14.5002 8.78982 14.2584L7.71575 15.9091C7.48984 16.2563 7.02526 16.3546 6.67807 16.1287C6.33089 15.9028 6.23257 15.4382 6.45847 15.091L7.37089 13.6888C6.5065 13.2667 5.74381 12.7502 5.07842 12.1983L4.11744 13.1592C3.82455 13.4521 3.34968 13.4521 3.05678 13.1592C2.76389 12.8664 2.76389 12.3915 3.05678 12.0986L3.98055 11.1748C3.15599 10.3151 2.53525 9.44656 2.10277 8.75468C1.83984 8.33404 1.6446 7.97566 1.51388 7.7197C1.44848 7.59164 1.3991 7.48895 1.36537 7.41665C1.3485 7.38048 1.33553 7.35189 1.32641 7.33149L1.31562 7.3071L1.31238 7.29966L1.31129 7.29714L1.31088 7.29619C1.31081 7.29602 1.31056 7.29545 1.99992 7.00001L1.31088 7.29619C1.14772 6.91547 1.32376 6.47382 1.70448 6.31065C2.08489 6.14762 2.52539 6.32356 2.68888 6.70363C2.68882 6.7035 2.68894 6.70376 2.68888 6.70363L2.68983 6.70582L2.69591 6.71953C2.7018 6.73273 2.7114 6.75392 2.72472 6.78249C2.75139 6.83965 2.79296 6.92626 2.84976 7.03748C2.96345 7.2601 3.13762 7.58028 3.37472 7.95961C3.85033 8.72048 4.57157 9.7071 5.55561 10.6216C6.42151 11.4263 7.48259 12.1676 8.75165 12.6558C9.70614 13.023 10.7854 13.25 11.9999 13.25C13.2416 13.25 14.342 13.0128 15.3124 12.6308C16.5738 12.1343 17.6277 11.3883 18.4866 10.582C19.4562 9.67198 20.1668 8.69517 20.6354 7.94321C20.869 7.56832 21.0405 7.25228 21.1525 7.03268C21.2085 6.92296 21.2494 6.83758 21.2757 6.78125C21.2888 6.7531 21.2983 6.73224 21.3041 6.71925L21.31 6.70577L21.3106 6.70457C21.3105 6.70467 21.3106 6.70447 21.3106 6.70457M22.2954 6.31065C21.9147 6.14753 21.4738 6.32405 21.3106 6.70457L22.2954 6.31065ZM2.68888 6.70363C2.68882 6.7035 2.68894 6.70376 2.68888 6.70363V6.70363Z"
                                          fill="#000"></path>
                                </svg>
                            </button>
                        </div>
                        <span class="text-danger error-message"></span>
                    </div>
                    <div class="form-item">
                        <label for="">Şifrənin təkrarı<sup>*</sup></label>
                        <div class="password">
                            <input type="password" id="new_password_confirmation" name="new_password_confirmation" placeholder="Şifrənin təkrarı">
                            <button class="show_password_btn" type="button">
                                <svg class="show-eye" width="20" height="20" viewBox="0 0 20 20" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M2.72843 12.7464C2.02015 11.8262 1.66602 11.3661 1.66602 9.99999C1.66602 8.63385 2.02015 8.17377 2.72843 7.2536C4.14265 5.41629 6.51444 3.33333 9.99935 3.33333C13.4843 3.33333 15.856 5.41629 17.2703 7.2536C17.9785 8.17377 18.3327 8.63385 18.3327 9.99999C18.3327 11.3661 17.9785 11.8262 17.2703 12.7464C15.856 14.5837 13.4843 16.6667 9.99935 16.6667C6.51444 16.6667 4.14265 14.5837 2.72843 12.7464Z"
                                        stroke="#000" stroke-width="1.5"></path>
                                    <path
                                        d="M12.5 10C12.5 11.3807 11.3807 12.5 10 12.5C8.61929 12.5 7.5 11.3807 7.5 10C7.5 8.61929 8.61929 7.5 10 7.5C11.3807 7.5 12.5 8.61929 12.5 10Z"
                                        stroke="#000" stroke-width="1.5"></path>
                                </svg>
                                <svg class="hidden-eye" width="24" height="24" viewBox="0 0 24 24" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                          d="M22.2954 6.31065C22.6761 6.47382 22.8524 6.91473 22.6893 7.29545L21.9999 7.00001C22.6893 7.29545 22.6894 7.29527 22.6893 7.29545L22.6886 7.29713L22.6875 7.29961L22.6843 7.30697L22.6736 7.33105C22.6646 7.35118 22.6518 7.3794 22.6352 7.41508C22.6019 7.48643 22.5533 7.58776 22.4888 7.71416C22.3599 7.96681 22.1675 8.32069 21.9084 8.73647C21.4828 9.41951 20.8724 10.2777 20.0619 11.1302L21.0303 12.0985C21.3231 12.3914 21.3231 12.8663 21.0303 13.1592C20.7374 13.4521 20.2625 13.4521 19.9696 13.1592L18.969 12.1586C18.3093 12.7113 17.5528 13.23 16.695 13.6562L17.6286 15.091C17.8545 15.4382 17.7562 15.9027 17.409 16.1286C17.0618 16.3546 16.5972 16.2562 16.3713 15.909L15.2821 14.2352C14.5028 14.4897 13.659 14.6626 12.7499 14.7246V16.5C12.7499 16.9142 12.4141 17.25 11.9999 17.25C11.5857 17.25 11.2499 16.9142 11.2499 16.5V14.7246C10.3689 14.6645 9.54909 14.5002 8.78982 14.2584L7.71575 15.9091C7.48984 16.2563 7.02526 16.3546 6.67807 16.1287C6.33089 15.9028 6.23257 15.4382 6.45847 15.091L7.37089 13.6888C6.5065 13.2667 5.74381 12.7502 5.07842 12.1983L4.11744 13.1592C3.82455 13.4521 3.34968 13.4521 3.05678 13.1592C2.76389 12.8664 2.76389 12.3915 3.05678 12.0986L3.98055 11.1748C3.15599 10.3151 2.53525 9.44656 2.10277 8.75468C1.83984 8.33404 1.6446 7.97566 1.51388 7.7197C1.44848 7.59164 1.3991 7.48895 1.36537 7.41665C1.3485 7.38048 1.33553 7.35189 1.32641 7.33149L1.31562 7.3071L1.31238 7.29966L1.31129 7.29714L1.31088 7.29619C1.31081 7.29602 1.31056 7.29545 1.99992 7.00001L1.31088 7.29619C1.14772 6.91547 1.32376 6.47382 1.70448 6.31065C2.08489 6.14762 2.52539 6.32356 2.68888 6.70363C2.68882 6.7035 2.68894 6.70376 2.68888 6.70363L2.68983 6.70582L2.69591 6.71953C2.7018 6.73273 2.7114 6.75392 2.72472 6.78249C2.75139 6.83965 2.79296 6.92626 2.84976 7.03748C2.96345 7.2601 3.13762 7.58028 3.37472 7.95961C3.85033 8.72048 4.57157 9.7071 5.55561 10.6216C6.42151 11.4263 7.48259 12.1676 8.75165 12.6558C9.70614 13.023 10.7854 13.25 11.9999 13.25C13.2416 13.25 14.342 13.0128 15.3124 12.6308C16.5738 12.1343 17.6277 11.3883 18.4866 10.582C19.4562 9.67198 20.1668 8.69517 20.6354 7.94321C20.869 7.56832 21.0405 7.25228 21.1525 7.03268C21.2085 6.92296 21.2494 6.83758 21.2757 6.78125C21.2888 6.7531 21.2983 6.73224 21.3041 6.71925L21.31 6.70577L21.3106 6.70457C21.3105 6.70467 21.3106 6.70447 21.3106 6.70457M22.2954 6.31065C21.9147 6.14753 21.4738 6.32405 21.3106 6.70457L22.2954 6.31065ZM2.68888 6.70363C2.68882 6.7035 2.68894 6.70376 2.68888 6.70363V6.70363Z"
                                          fill="#000"></path>
                                </svg>
                            </button>
                        </div>
                        <span class="text-danger error-message"></span>
                    </div>
                </div>
                <button class="editAgentModalBtn" type="submit">Düzəliş et</button>
            </form>

        </div>
    </div>
@endsection

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
@if (session('success'))
    <script>
        $(document).ready(function() {
            toastr.success('{{ session('success') }}', 'Success');
        });
    </script>
@endif
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Select all edit buttons
        const editButtons = document.querySelectorAll('.agentEdit');

        // Add event listener to each edit button
        editButtons.forEach((button) => {
            button.addEventListener('click', function () {
                // Find the parent row and get user data
                const row = this.closest('tr');
                const userId = row.getAttribute('data-user-id'); // Set a data attribute for user id on the row
                const name = row.querySelector('.agentFullName').innerText.split(' ')[0];
                const surname = row.querySelector('.agentFullName').innerText.split(' ')[1];
                const email = row.querySelector('.agentMail').innerText;
                const phone = row.querySelector('.agentNumber').innerText;

                // Populate the modal form with data
                document.querySelector('#name').value = name;
                document.querySelector('#surname').value = surname;
                document.querySelector('#phone').value = phone;
                document.querySelector('#email').value = email;
                document.querySelector('.form_editAgentModal').setAttribute('data-user-id', userId);

                // Open the modal
                document.querySelector('.editAgentModal').classList.add('open');
            });
        });

        // Close modal button
        document.querySelector('.closeEditAgentModal').addEventListener('click', function () {
            document.querySelector('.editAgentModal').classList.remove('open');
        });
    });

    $(document).on('submit', '.form_editAgentModal', function (e) {
        e.preventDefault();

        $('.error-message').text('');

        const userId = $('.form_editAgentModal').data('user-id');
        const formData = {
            name: $('#name').val(),
            surname: $('#surname').val(),
            phone: $('#phone').val(),
            email: $('#email').val(),
            new_password: $('#new_password').val(),
            new_password_confirmation: $('#new_password_confirmation').val(),
            _token: $('meta[name="csrf-token"]').attr('content')
        };

        $.ajax({
            url: `/agents/${userId}`,
            method: 'PUT',
            data: formData,
            success: function (response) {
                location.reload();
            },
            error: function (xhr) {
                if (xhr.responseJSON && xhr.responseJSON.errors) {
                    const errors = xhr.responseJSON.errors;
                    for (const [field, messages] of Object.entries(errors)) {
                        const input = $(`#${field}`);
                        const errorContainer = input.siblings('.error-message');
                        errorContainer.text(messages.join(' '));
                    }
                } else {
                    console.log('error var');
                }
            }
        });
    });



</script>


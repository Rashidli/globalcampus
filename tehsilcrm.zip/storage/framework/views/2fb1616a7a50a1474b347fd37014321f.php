<nav>
    <div class="navbar-top">
        <a href="<?php echo e(route('home')); ?>" class="nav-logo">
            <img src="<?php echo e(asset('/')); ?>assets/images/logo.svg" alt="">
        </a>
        <button class="hamburger" type="button">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 7L2 7" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round"/>
                <path d="M19 12L5 12" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round"/>
                <path d="M16 17H8" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
        </button>
    </div>
    <div class="navbar-menu">
        <div class="navbar-menu-top">
            <p>Menu</p>
            <button class="closeMenu" type="button">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 6L6 18" stroke="#1C274C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M6 6L18 18" stroke="#1C274C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
        </div>
        <div class="navbar-menu-links">
            <a href="<?php echo e(route('home')); ?>" class="navbar-menu-link active">
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M5.70356 4.21762C6.11108 3.94533 6.53897 3.70916 6.98232 3.51061C8.23987 2.94743 8.86865 2.66584 9.70515 3.20778C10.5416 3.74972 10.5416 4.6387 10.5416 6.41667V7.79167C10.5416 9.52015 10.5416 10.3844 11.0786 10.9214C11.6156 11.4583 12.4798 11.4583 14.2083 11.4583H15.5833C17.3613 11.4583 18.2503 11.4583 18.7922 12.2948C19.3341 13.1313 19.0526 13.7601 18.4894 15.0177C18.2908 15.461 18.0547 15.8889 17.7824 16.2964C16.8255 17.7285 15.4654 18.8447 13.8742 19.5038C12.2829 20.1629 10.532 20.3353 8.84274 19.9993C7.15349 19.6633 5.60181 18.8339 4.38393 17.6161C3.16605 16.3982 2.33666 14.8465 2.00065 13.1572C1.66463 11.468 1.83709 9.71704 2.4962 8.1258C3.15531 6.53456 4.27148 5.1745 5.70356 4.21762Z" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M19.6588 6.47991C18.9147 4.59094 17.409 3.08529 15.5201 2.34114C14.107 1.78445 12.8333 3.06455 12.8333 4.58333V8.25C12.8333 8.75626 13.2437 9.16667 13.75 9.16667H17.4166C18.9354 9.16667 20.2155 7.89299 19.6588 6.47991Z" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                </svg>
                Statistika
            </a>
            <a href="<?php echo e(route('students.index')); ?>" class="navbar-menu-link ">
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="8.24998" cy="5.49998" r="3.66667" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M13.75 8.25C15.2688 8.25 16.5 7.01878 16.5 5.5C16.5 3.98122 15.2688 2.75 13.75 2.75" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <ellipse cx="8.24998" cy="15.5834" rx="6.41667" ry="3.66667" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M16.5 12.8333C18.1081 13.186 19.25 14.079 19.25 15.125C19.25 16.0685 18.3207 16.8877 16.9583 17.2979" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                Tələbələr
            </a>
            <a href="employees.html" class="navbar-menu-link ">
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2.75 11C2.75 14.457 2.75 18.0188 3.95818 19.0927C5.16637 20.1667 7.11091 20.1667 11 20.1667C14.8891 20.1667 16.8336 20.1667 18.0418 19.0927C19.25 18.0188 19.25 14.457 19.25 11" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M13.4386 13.0184L18.9453 11.3664C19.4912 11.2026 19.7641 11.1208 19.9373 10.9245C19.971 10.8863 20.0015 10.8453 20.0284 10.802C20.1666 10.5797 20.1666 10.2948 20.1666 9.72485C20.1666 7.47888 20.1666 6.35589 19.5497 5.59771C19.4312 5.45199 19.298 5.3188 19.1523 5.20023C18.3941 4.58333 17.2711 4.58333 15.0251 4.58333H6.97483C4.72886 4.58333 3.60587 4.58333 2.84769 5.20023C2.70197 5.3188 2.56878 5.45199 2.45021 5.59771C1.83331 6.35589 1.83331 7.47888 1.83331 9.72485C1.83331 10.2948 1.83331 10.5797 1.97153 10.802C1.99845 10.8453 2.02894 10.8863 2.06267 10.9245C2.23587 11.1208 2.50881 11.2026 3.05468 11.3664L8.56135 13.0184" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M5.95831 4.58333C6.71314 4.56421 7.47929 4.08367 7.73614 3.37363C7.74404 3.35179 7.75213 3.32749 7.76833 3.27889L7.79185 3.20833C7.83052 3.09232 7.84987 3.03429 7.87055 2.98284C8.13473 2.3257 8.75379 1.8795 9.46075 1.83669C9.51611 1.83333 9.57726 1.83333 9.69956 1.83333H12.3008C12.4231 1.83333 12.4843 1.83333 12.5396 1.83669C13.2466 1.8795 13.8656 2.3257 14.1298 2.98284C14.1505 3.0343 14.1698 3.09231 14.2085 3.20833L14.232 3.27889C14.2481 3.32721 14.2564 3.35185 14.2642 3.37363C14.5211 4.08367 15.2868 4.56421 16.0416 4.58333" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M12.8333 11.4583H9.16665C8.91352 11.4583 8.70831 11.6635 8.70831 11.9167V13.898C8.70831 14.0854 8.82242 14.254 8.99643 14.3236L9.63821 14.5803C10.5124 14.93 11.4876 14.93 12.3617 14.5803L13.0035 14.3236C13.1775 14.254 13.2916 14.0854 13.2916 13.898V11.9167C13.2916 11.6635 13.0864 11.4583 12.8333 11.4583Z" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                İşçilər
            </a>
            <a href="universities.html" class="navbar-menu-link ">
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8.96747 3.20801C10.2701 2.59733 11.7298 2.59733 13.0324 3.20801L19.166 6.08358C20.5002 6.70908 20.5002 8.8743 19.166 9.49979L13.0325 12.3753C11.7299 12.986 10.2701 12.986 8.96755 12.3753L2.83395 9.49975C1.49977 8.87426 1.49977 6.70904 2.83395 6.08354L8.96747 3.20801Z" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M1.83331 7.79166V12.8333" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M17.4166 10.5417V15.24C17.4166 16.164 16.9551 17.0291 16.1468 17.4768C14.8008 18.2222 12.6463 19.25 11 19.25C9.35364 19.25 7.19921 18.2222 5.8532 17.4768C5.04486 17.0291 4.58331 16.164 4.58331 15.24V10.5417" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                Universitetlər
            </a>
            <a href="university_categories.html" class="navbar-menu-link ">
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2.29169 5.95834C2.29169 3.93329 3.93331 2.29167 5.95835 2.29167C7.9834 2.29167 9.62502 3.93329 9.62502 5.95834V8.40278C9.62502 8.68694 9.62502 8.82902 9.59379 8.94559C9.50902 9.26192 9.26194 9.50901 8.9456 9.59377C8.82903 9.625 8.68696 9.625 8.4028 9.625H5.95835C3.93331 9.625 2.29169 7.98338 2.29169 5.95834Z" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M12.375 13.5972C12.375 13.3131 12.375 13.171 12.4062 13.0544C12.491 12.7381 12.7381 12.491 13.0544 12.4062C13.171 12.375 13.3131 12.375 13.5972 12.375H16.0417C18.0667 12.375 19.7083 14.0166 19.7083 16.0417C19.7083 18.0667 18.0667 19.7083 16.0417 19.7083C14.0166 19.7083 12.375 18.0667 12.375 16.0417V13.5972Z" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M2.29169 16.0417C2.29169 14.0166 3.93331 12.375 5.95835 12.375H8.15835C8.67173 12.375 8.92843 12.375 9.12451 12.4749C9.29699 12.5628 9.43723 12.703 9.52511 12.8755C9.62502 13.0716 9.62502 13.3283 9.62502 13.8417V16.0417C9.62502 18.0667 7.9834 19.7083 5.95835 19.7083C3.93331 19.7083 2.29169 18.0667 2.29169 16.0417Z" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M12.375 5.95834C12.375 3.93329 14.0166 2.29167 16.0417 2.29167C18.0667 2.29167 19.7083 3.93329 19.7083 5.95834C19.7083 7.98338 18.0667 9.625 16.0417 9.625H13.4226C13.301 9.625 13.2402 9.625 13.189 9.61924C12.764 9.57136 12.4286 9.23596 12.3808 8.81097C12.375 8.75982 12.375 8.69901 12.375 8.57739V5.95834Z" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                </svg>
                Universitet kateqoriyaları
            </a>
            <a href="<?php echo e(route('agents.index')); ?>" class="navbar-menu-link ">
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20.1666 20.1667L1.83331 20.1667" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M19.25 20.1667V5.49999C19.25 3.77151 19.25 2.90727 18.7131 2.3703C18.1761 1.83333 17.3118 1.83333 15.5834 1.83333H13.75C12.0215 1.83333 11.1573 1.83333 10.6203 2.3703C10.1881 2.80255 10.1038 3.44686 10.0873 4.58333" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M13.75 20.1667V8.24999C13.75 6.52151 13.75 5.65727 13.213 5.1203C12.6761 4.58333 11.8118 4.58333 10.0833 4.58333H6.41667C4.68818 4.58333 3.82394 4.58333 3.28697 5.1203C2.75 5.65727 2.75 6.52151 2.75 8.24999V20.1667" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M8.25 20.1667V17.4167" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M5.5 7.33333H11" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M5.5 10.0833H11" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M5.5 12.8333H11" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                Agentlər
            </a>
            <a href="finance.html" class="navbar-menu-link ">
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="11" cy="11" r="9.16667" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M11 5.5V16.5" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M13.75 8.70832C13.75 7.44267 12.5188 6.41666 11 6.41666C9.48122 6.41666 8.25 7.44267 8.25 8.70832C8.25 9.97398 9.48122 11 11 11C12.5188 11 13.75 12.026 13.75 13.2917C13.75 14.5573 12.5188 15.5833 11 15.5833C9.48122 15.5833 8.25 14.5573 8.25 13.2917" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                Maliyyə
            </a>
            <a href="services.html" class="navbar-menu-link ">
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14.6667 3.66827C16.6604 3.67937 17.7402 3.76779 18.4445 4.47214C19.25 5.27759 19.25 6.57396 19.25 9.16668V14.6667C19.25 17.2594 19.25 18.5558 18.4445 19.3612C17.6391 20.1667 16.3427 20.1667 13.75 20.1667H8.25C5.65728 20.1667 4.36091 20.1667 3.55546 19.3612C2.75 18.5558 2.75 17.2594 2.75 14.6667V9.16668C2.75 6.57396 2.75 5.27759 3.55546 4.47214C4.25981 3.76779 5.33956 3.67937 7.33333 3.66827" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                    <path d="M9.625 12.8333L15.5833 12.8333" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M6.41669 12.8333H6.87502" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M6.41669 9.625H6.87502" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M6.41669 16.0417H6.87502" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M9.625 9.625H15.5833" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M9.625 16.0417H15.5833" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M7.33331 3.20834C7.33331 2.44895 7.94892 1.83334 8.70831 1.83334H13.2916C14.051 1.83334 14.6666 2.44895 14.6666 3.20834V4.12501C14.6666 4.8844 14.051 5.50001 13.2916 5.50001H8.70831C7.94892 5.50001 7.33331 4.8844 7.33331 4.12501V3.20834Z" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                </svg>
                Xidmətlərimiz
            </a>
        </div>
        <div class="navbar-menu-bottom">
            <p>Digər</p>
            <div class="navbar-menu-bottom-links">
                <a href="notification.html" class="navbar-menu-bottom-link">
                    <svg width="22" height="24" viewBox="0 0 22 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M17.4167 10.8955V10.25C17.4167 6.70621 14.5438 3.83337 11 3.83337C7.45619 3.83337 4.58335 6.70621 4.58335 10.25V10.8955C4.58335 11.67 4.35408 12.4273 3.92442 13.0718L2.87153 14.6511C1.90983 16.0937 2.64401 18.0545 4.31666 18.5106C8.69233 19.704 13.3077 19.704 17.6834 18.5106C19.356 18.0545 20.0902 16.0937 19.1285 14.6511L18.0756 13.0718C17.646 12.4273 17.4167 11.67 17.4167 10.8955Z" stroke="black" stroke-opacity="0.7" stroke-width="1.5"/>
                        <path d="M6.875 19.4166C7.47544 21.0188 9.09558 22.1666 11 22.1666C12.9044 22.1666 14.5246 21.0188 15.125 19.4166" stroke="black" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                    </svg>
                    Bildirişlər
                    <span>55</span>
                </a>
                <a href="<?php echo e(route('logout')); ?>" class="exitProfile" type="button">
                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8.25177 6.41671C8.26287 4.42293 8.35128 3.34318 9.05563 2.63883C9.86109 1.83337 11.1575 1.83337 13.7502 1.83337L14.6668 1.83337C17.2596 1.83337 18.5559 1.83337 19.3614 2.63883C20.1668 3.44429 20.1668 4.74065 20.1668 7.33337L20.1668 14.6667C20.1668 17.2594 20.1668 18.5558 19.3614 19.3613C18.5559 20.1667 17.2596 20.1667 14.6668 20.1667H13.7502C11.1575 20.1667 9.86109 20.1667 9.05563 19.3613C8.35128 18.6569 8.26287 17.5771 8.25177 15.5834" stroke="#FF1346" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round"/>
                        <path d="M13.75 11L1.83333 11M1.83333 11L5.04167 8.25M1.83333 11L5.04167 13.75" stroke="#FF1346" stroke-opacity="0.7" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Çıxış
                </a>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\projects\tehsilcrm\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>
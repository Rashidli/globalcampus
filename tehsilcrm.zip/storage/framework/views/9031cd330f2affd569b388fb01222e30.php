<script src="<?php echo e(asset('/')); ?>assets/jquery-nice-select-1.1.0/js/jquery.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/jquery-nice-select-1.1.0/js/jquery.nice-select.min.js"></script>
<script>
    $(document).ready(function () {
        $('select').niceSelect()
    })
</script>
<script src="<?php echo e(asset('/')); ?>assets/swiper/swiper.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/js/index.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/js/script.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\projects\tehsilcrm\resources\views/partials/footer.blade.php ENDPATH**/ ?>
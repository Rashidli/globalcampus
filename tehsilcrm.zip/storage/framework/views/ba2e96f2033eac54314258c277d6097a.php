<div class="form-items">
    <div class="form-item">
        <label for="">Təhsil müəssisəsi<sup>*</sup></label>
        <input type="text" name="university[]" placeholder="Məktəb, Peşə, Universitet">
    </div>
    <div class="form-item">
        <label for="">Başlama tarixi<sup>*</sup></label>
        <input type="date" name="start_date[]" placeholder="Ay/İl">
    </div>
    <div class="form-item">
        <label for="">Bitmə tarixi<sup>*</sup></label>
        <input type="date" name="end_date[]" placeholder="Ay/İl">
    </div>
</div>
<button type="button" class="deleteInfoForm">
    <img src="<?php echo e(asset('/')); ?>assets/images/trash.svg" alt="">
    Sil
</button>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\projects\tehsilcrm\resources\views/components/education.blade.php ENDPATH**/ ?>
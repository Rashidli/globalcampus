<div class="page-head">
    <h1><?php echo $__env->yieldContent('title'); ?></h1>
    <div class="head-userProfile">
        <h2><?php echo e(auth()->user()->name); ?> <?php echo e(auth()->user()->surname); ?></h2>
        <!-- Burada userin ad ve soyadinin ilk herifi olacaq -->
        <p><?php echo e(mb_substr(auth()->user()->name, 0, 1)); ?><?php echo e(mb_substr(auth()->user()->surname, 0, 1)); ?></p>
    </div>
</div>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\projects\tehsilcrm\resources\views/partials/header.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use App\Http\Requests\RegisterRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;

class AgentController extends Controller
{
    public function __construct()
    {
//        $this->middleware('permission:list-users|create-users|edit-users|delete-users', ['only' => ['index','show']]);
//        $this->middleware('permission:create-users', ['only' => ['create','store']]);
//        $this->middleware('permission:edit-users', ['only' => ['edit']]);
//        $this->middleware('permission:delete-users', ['only' => ['destroy']]);
    }

    /**
     * Display a listing of the resource.
     */

    public function index(Request $request)
    {

        $query = User::query();

        if($request->search){
            $query->where('name', 'like','%'. $request->search .'%')
                ->orWhere('surname', 'like', '%' . $request->search . '%');
        }

        $users = $query->orderByDesc('id')->where('type','agent')->paginate(10);

        return view('agents.index',compact('users'));

    }

    /**
     * Show the form for creating a new resource.
     */

    public function create()
    {
        $roles = Role::all();
        return view('agents.create', compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     */

    public function store(RegisterRequest $request)
    {

//        dd($request->all());
        $user = new User([
            'name' => $request->input('name'),
            'surname' => $request->input('surname'),
            'phone' => $request->input('phone'),
            'email' => $request->input('email'),
            'type' =>'agent',
            'password' => Hash::make($request->input('password')),
        ]);

//        $user->assignRole($request->role);

//        if($request->role){
//            foreach ($request->role as $r){
//                $user->assignRole($r);
//            }
//        }


        $user->save();

//        Auth::login($user);

        return redirect()->route('agents.index')->with('message', 'Agent əlavə edildi');

    }

    /**
     * Display the specified resource.
     */

    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */

    public function edit($id)
    {

        $user = User::query()->findOrFail($id);
        return response()->json($user);

    }

    /**
     * Update the specified resource in storage.
     */

    public function update(Request $request, $id)
    {
        $user = User::query()->findOrFail($id);
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'surname' => 'required|string|max:255',
            'phone' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $user->id . '|max:255',
            'new_password' => 'nullable|string|min:6|confirmed',
        ]);

        $user->name = $validatedData['name'];
        $user->surname = $validatedData['surname'];
        $user->phone = $validatedData['phone'];
        $user->email = $validatedData['email'];

        if (!empty($validatedData['new_password'])) {
            $user->password = Hash::make($validatedData['new_password']);
        }

        $user->save();
        session()->flash('success', 'Successfully updated');
        return response()->json(['message' => 'Successfully updated']);

    }



    /**
     * Remove the specified resource from storage.
     */

    public function destroy($id)
    {
        $user = User::query()->findOrFail($id);
        $user->delete();
        return redirect()->route('agents.index')->with('success','İstifadəçi silindi');
    }
}

<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreUserRequest;
use App\Http\Services\UserService;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Role;

class StudentController extends Controller
{
    private $userService;


    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
//        $this->middleware('permission:list-users|create-users|edit-users|delete-users', ['only' => ['index','show']]);
//        $this->middleware('permission:create-users', ['only' => ['create','store']]);
//        $this->middleware('permission:edit-users', ['only' => ['edit']]);
//        $this->middleware('permission:delete-users', ['only' => ['destroy']]);
    }

    /**
     * Display a listing of the resource.
     */

    public function index(Request $request)
    {

        $query = User::query();

        if($request->search){
            $query->where('name', 'like','%'. $request->search .'%')
                ->orWhere('surname', 'like', '%' . $request->search . '%');
        }

        if($request->status){
            $query->where('status', $request->status);
        }

        $users = $query->orderByDesc('id')->where('type','student')->paginate(10);

        return view('students.index',compact('users'));

    }

    /**
     * Show the form for creating a new resource.
     */

    public function create()
    {
        $agents = User::query()->where('type','agent')->get();
        return view('students.create', compact('agents'));
    }

    /**
     * Store a newly created resource in storage.
     */

    public function store(StoreUserRequest $request)
    {

        $validatedData = $request->validated();

        $user = $this->userService->createUser($validatedData);

        $this->userService->addEducations($user, $this->mapEducations($request));
        $this->userService->addExperiences($user, $this->mapExperiences($request));
        $this->userService->addLanguages($user, $this->mapLanguages($request));
        $this->userService->addPrograms($user, $this->mapPrograms($request));

        if ($request->hasFile('file')) {
            $this->userService->addDocuments($user, $request->file('file'), $validatedData['file_title']);
        }

        return redirect()->route('students.index')->with('message', 'Student əlavə edildi');

    }

    private function mapEducations(Request $request): array
    {
        return collect($request->university ?? [])->map(function ($university, $index) use ($request) {
            return [
                'university' => $university,
                'university_start_date' => $request->start_date[$index] ?? null,
                'university_end_date' => $request->end_date[$index] ?? null,
            ];
        })->toArray();
    }

    private function mapExperiences(Request $request): array
    {
        return collect($request->experience_company ?? [])->map(function ($company, $index) use ($request) {
            return [
                'experience_company' => $company,
                'position' => $request->position[$index] ?? null,
                'experience_start_date' => $request->experience_start_date[$index] ?? null,
                'experience_end_date' => $request->experience_end_date[$index] ?? null,
            ];
        })->toArray();
    }

    private function mapLanguages(Request $request): array
    {
        return collect($request->language ?? [])->map(function ($language, $index) use ($request) {
            return [
                'language' => $language,
                'level' => $request->level[$index] ?? null,
            ];
        })->toArray();
    }

    private function mapPrograms(Request $request): array
    {
        return collect($request->program_name ?? [])->map(function ($program, $index) use ($request) {
            return [
                'program_name' => $program,
                'country' => $request->country[$index] ?? null,
                'city' => $request->city[$index] ?? null,
                'program_date' => $request->program_date[$index] ?? null,
            ];
        })->toArray();
    }

    /**
     * Display the specified resource.
     */

    public function show(string $id)
    {

        $user = User::query()->with(
            'educations',
            'experiences',
            'languages',
            'programs',
            'documents')
            ->findOrFail($id);
        return view('students.show', compact('user'));

    }

    /**
     * Show the form for editing the specified resource.
     */

    public function edit($id)
    {

        $user = User::query()->with(
            'educations',
            'experiences',
            'languages',
            'programs',
            'documents')
            ->findOrFail($id);
        $agents = User::query()->where('type','agent')->get();
        return view('students.edit', compact('user', 'agents'));

    }

    /**
     * Update the specified resource in storage.
     */

    public function update(Request $request, $id)
    {
        $user = User::query()->findOrFail($id);
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'surname' => 'required|string|max:255',
            'phone' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $user->id . '|max:255',
            'new_password' => 'nullable|string|min:6|confirmed',
        ]);

        $user->name = $validatedData['name'];
        $user->surname = $validatedData['surname'];
        $user->phone = $validatedData['phone'];
        $user->email = $validatedData['email'];

        if (!empty($validatedData['new_password'])) {
            $user->password = Hash::make($validatedData['new_password']);
        }

        $user->save();
        session()->flash('success', 'Successfully updated');
        return response()->json(['message' => 'Successfully updated']);

    }



    /**
     * Remove the specified resource from storage.
     */

    public function destroy($id)
    {
        $user = User::query()->findOrFail($id);
        $user->delete();
        return redirect()->route('students.index')->with('success','İstifadəçi silindi');
    }
}

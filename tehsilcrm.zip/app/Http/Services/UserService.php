<?php

namespace App\Http\Services;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserService
{
    public function createUser(array $data): User
    {
        return User::create([
            'name' => $data['name'],
            'surname' => $data['surname'],
            'contact_email' => $data['contact_email'] ?? null,
            'phone' => $data['phone'],
            'father_name' => $data['father_name'],
            'birthday' => $data['birthday'],
            'address' => $data['address'] ?? null,
            'marital_status' => $data['marital_status'],
            'gender' => $data['gender'],
            'agent_id' => $data['agent_id'],
            'email' => $data['email'],
            'status' => 'accepted',
            'type' => 'student',
            'password' => Hash::make($data['password']),
        ]);
    }

    public function addEducations(User $user, array $educations): void
    {
        $user->educations()->createMany(array_filter($educations, function ($education) {
            return !empty($education['university']);
        }));
    }

    public function addExperiences(User $user, array $experiences): void
    {
        $user->experiences()->createMany(array_filter($experiences, function ($experience) {
            return !empty($experience['experience_company']);
        }));
    }

    public function addLanguages(User $user, array $languages): void
    {
        $user->languages()->createMany(array_filter($languages, function ($language) {
            return !empty($language['language']);
        }));
    }

    public function addPrograms(User $user, array $programs): void
    {
        $user->programs()->createMany(array_filter($programs, function ($program) {
            return !empty($program['program_name']);
        }));
    }

    public function addDocuments(User $user, array $files, array $fileTitles): void
    {
        foreach ($files as $index => $file) {
            $filename = Str::uuid() . '.' . $file->extension();
            $file->storeAs('public/', $filename);

            $user->documents()->create([
                'file_title' => $fileTitles[$index] ?? 'Untitled',
                'file' => $filename,
            ]);
        }
    }
}

<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'surname' => 'required|string|max:255',
            'phone' => 'required|string|max:255',
            'father_name' => 'required|string|max:255',
            'birthday' => 'required|date',
            'address' => 'nullable|string|max:255',
            'marital_status' => 'required|string|max:255',
            'gender' => 'required|string|max:255',
            'contact_email' => 'nullable|email',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8',
            'agent_id' => 'required|integer',
            'university' => 'array',
            'start_date' => 'array',
            'end_date' => 'array',
            'experience_company' => 'array',
            'position' => 'array',
            'experience_start_date' => 'array',
            'experience_end_date' => 'array',
            'language' => 'array',
            'level' => 'array',
            'program_name' => 'array',
            'country' => 'array',
            'city' => 'array',
            'program_date' => 'array',
            'file' => 'array',
            'file_title' => 'array',
        ];
    }
}

document.querySelectorAll('.document-input-box').forEach((box) => {
    const input = box.querySelector('input[type="file"]');
    const fileNameSpan = box.querySelector('.fileName');
    const resetButton = box.querySelector('.resetDocumentBox');

    input?.addEventListener('change', (e) => {
        if (input.files.length > 0) {
            const fileName = input.files[0].name; // Faylın adı
            fileNameSpan.textContent = fileName; // Fayl adını yaz
            if (!box.classList.contains('added-file')) {
                box.classList.add('added-file'); // `added` class-ı əlavə et
            }
        }
    });

    // Reset düyməsinə kliklənəndə
    resetButton?.addEventListener('click', () => {
        input.value = ''; // Fayl seçimini sıfırla
        fileNameSpan.textContent = ''; // Fayl adını sil
        box.classList.remove('added-file'); // `added` class-ını sil
    });
});
const uploadFileBox = document.querySelector('.document-input-item');
if (uploadFileBox) {
  const input = uploadFileBox.querySelector('input[type="file"]');
  const fileNameSpan = uploadFileBox.querySelector('.fileName');

  input?.addEventListener('change', () => {
    if (input.files.length > 0) {
      const fileName = input.files[0].name; // Dosyanın adı
      fileNameSpan.textContent = fileName; // Dosya adını yazdır
      if (!uploadFileBox.classList.contains('added-file')) {
        uploadFileBox.classList.add('added-file'); // `added-file` sınıfını ekle
      }
    }
  });
}


const studentServiceInputs = document.querySelectorAll(".student-service-list .student-service-item .servicePrice input");
const studentCostInputs = document.querySelectorAll(".student-cost-list .student-cost-item .costPrice input");
  
  const updateWidth = (input) => {
    const valueLength = input.value.length || input.placeholder.length; // Değer veya placeholder uzunluğu
    const newWidth = valueLength*10; // Her karakter için genişlik (örnek: 10px per char)
    input.style.width = `${newWidth}px`; // Genişliği ayarla
  };
  
  // Her input için event listener ekle
  studentServiceInputs.forEach((input) => {
    input.addEventListener("input", () => updateWidth(input));
  
    // Sayfa yüklendiğinde genişliği başlangıç için güncelle
    window.addEventListener("DOMContentLoaded", () => updateWidth(input));
  });
  studentCostInputs.forEach((input) => {
    input.addEventListener("input", () => updateWidth(input));
  
    // Sayfa yüklendiğinde genişliği başlangıç için güncelle
    window.addEventListener("DOMContentLoaded", () => updateWidth(input));
  });

    const student_detail_tabs = document.querySelectorAll(".student-detail-tab");
    const student_detail_tabContents = document.querySelectorAll(".student-tabContent");
    
    student_detail_tabs.forEach(student_detail_tab => {
            student_detail_tab?.addEventListener("click", () => {
            student_detail_tabs.forEach(tab => tab.classList.remove("active"));
            student_detail_tab.classList.add("active");
            student_detail_tabContents.forEach(tabContent => tabContent.style.display = "none");
            const id = student_detail_tab.id;
            document.querySelector(`.student-tabContent[data-id="${id}"]`).style.display = "flex";
        });
    });


const disableStudentBtn = document.querySelector(".disableStudent");
disableStudentBtn?.addEventListener("click",()=>{
  disableStudentBtn.classList.toggle("disabled")
})


const deleteStudentBtn = document.querySelector(".deleteStudent");
const deleteStudentModal = document.querySelector(".deleteStudentModal");
const closeDeleteStudentModal = document.querySelector(".closeDeleteStudentModal");
const deleteStudent_no = document.querySelector(".deleteStudent_no");
deleteStudentBtn?.addEventListener("click",()=>{
  deleteStudentModal.style.display="flex"
})
closeDeleteStudentModal?.addEventListener("click",()=>{
  deleteStudentModal.style.display="none"
})
deleteStudent_no?.addEventListener("click",()=>{
  deleteStudentModal.style.display="none"
})



const uploadStudentDocumentModal = document.querySelector(".uploadStudentDocumentModal");
const closeUploadStudentDocument = document.querySelector(".closeUploadStudentDocument");
const addNewStudentDocument = document.querySelector(".addNewStudentDocument");

closeUploadStudentDocument?.addEventListener("click",()=>{
  uploadStudentDocumentModal.style.display="none"
})
addNewStudentDocument?.addEventListener("click",()=>{
  uploadStudentDocumentModal.style.display="flex"
})

const editStudentModal = document.querySelector(".editStudentModal");
const closeEditStudentModal = document.querySelector(".closeEditStudentModal");
const editInfoBtn = document.querySelector(".editInfoBtn");

closeEditStudentModal?.addEventListener("click",()=>{
  editStudentModal.style.display="none"
})
editInfoBtn?.addEventListener("click",()=>{
  editStudentModal.style.display="flex"
})

document.querySelectorAll('.show_password_btn').forEach(button => {
  button?.addEventListener('click', () => {
      const input = button.previousElementSibling;
      if (button.classList.toggle('active')) {
          input.type = 'text';
      } else {
          input.type = 'password';
      }
  });
});


const editAgentModal = document.querySelector(".editAgentModal");
const closeEditAgentModal = document.querySelector(".closeEditAgentModal");
const agentEdits = document.querySelectorAll(".agentEdit");
const updatePassBtnText = document.querySelector(".updatePassBtnText");
const changesAgentPass = document.querySelector(".changesAgentPass");

closeEditAgentModal?.addEventListener("click",()=>{
  editAgentModal.style.display="none"
    changesAgentPass.style.display="none"
    updatePassBtnText.style.display="block"
})
agentEdits.forEach(agentEdit=>{
  agentEdit?.addEventListener("click",()=>{
    editAgentModal.style.display="flex"
  })
})

updatePassBtnText?.addEventListener("click",()=>{
  changesAgentPass.style.display="grid"
  updatePassBtnText.style.display="none"
})

const notificationModalContainer = document.querySelector(".notificationModal-container");
const close_notification = document.querySelector(".close_notification");

close_notification?.addEventListener("click",()=>{
  notificationModalContainer.style.display="none"
})


const editEmployeeModal = document.querySelector(".editEmployeeModal");
const closeEditEmployeeModal = document.querySelector(".closeEditEmployeeModal");
const employeeEdits = document.querySelectorAll(".employeeEdit");

closeEditEmployeeModal?.addEventListener("click",()=>{
  editEmployeeModal.style.display="none"
})
employeeEdits.forEach(employeeEdit=>{
  employeeEdit?.addEventListener("click",()=>{
    editEmployeeModal.style.display="flex"
  })
})


const editUniversityCategoryModal = document.querySelector(".editUniversityCategoryModal");
const closeEditUniversityCategoryModal = document.querySelector(".closeEditUniversityCategoryModal");
const universityCategoryEdits = document.querySelectorAll(".universityCategoryEdit");

closeEditUniversityCategoryModal?.addEventListener("click",()=>{
  editUniversityCategoryModal.style.display="none"
})
universityCategoryEdits.forEach(universityCategoryEdit=>{
  universityCategoryEdit?.addEventListener("click",()=>{
    editUniversityCategoryModal.style.display="flex"
  })
})

const addUniversityCategoryModal = document.querySelector(".addUniversityCategoryModal");
const closeAddUniversityCategoryModal = document.querySelector(".closeAddUniversityCategoryModal");
const addNewUniversityCategory = document.querySelector(".addNewUniversityCategory");

closeAddUniversityCategoryModal?.addEventListener("click",()=>{
  addUniversityCategoryModal.style.display="none"
})
addNewUniversityCategory?.addEventListener("click",()=>{
  addUniversityCategoryModal.style.display="flex"
})




const editServiceModal = document.querySelector(".editServiceModal");
const closeEditServiceModal = document.querySelector(".closeEditServiceModal");
const serviceCategoryEdits = document.querySelectorAll(".serviceCategoryEdit");

closeEditServiceModal?.addEventListener("click",()=>{
  editServiceModal.style.display="none"
})
serviceCategoryEdits.forEach(serviceCategoryEdit=>{
  serviceCategoryEdit?.addEventListener("click",()=>{
    editServiceModal.style.display="flex"
  })
})

const addServiceModal = document.querySelector(".addServiceModal");
const closeAddServiceModal = document.querySelector(".closeAddServiceModal");
const addNewService = document.querySelector(".addNewService");

closeAddServiceModal?.addEventListener("click",()=>{
  addServiceModal.style.display="none"
})
addNewService?.addEventListener("click",()=>{
  addServiceModal.style.display="flex"
})
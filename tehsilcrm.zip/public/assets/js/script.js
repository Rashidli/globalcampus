document.addEventListener("DOMContentLoaded", function () {
    const educationFormsContainer = document.getElementById("educationFormsContainer");
    const addEducationButton = document.getElementById("addEducation");

    addEducationButton.addEventListener("click", () => {
        const newEducationForm = document.createElement("div");
        newEducationForm.classList.add("educationFormLine");

        newEducationForm.innerHTML = `
        <div class="form-items">
            <div class="form-item">
                <label for="">Təhsil müəssisəsi<sup>*</sup></label>
                <input type="text" name="university[]" placeholder="Məktəb, Peşə, Universitet">
            </div>
            <div class="form-item">
                <label for="">Başlama tarixi<sup>*</sup></label>
                <input type="date" name="start_date[]" placeholder="Ay/İl">
            </div>
            <div class="form-item">
                <label for="">Bitmə tarixi<sup>*</sup></label>
                <input type="date" name="end_date[]" placeholder="Ay/İl">
            </div>
        </div>
        <button type="button" class="deleteInfoForm">
            <img src="${assetBasePath}assets/images/trash.svg" alt="">
            Sil
        </button>
    `;

        newEducationForm.querySelector(".deleteInfoForm").addEventListener("click", function () {
            newEducationForm.remove();
        });

        educationFormsContainer.appendChild(newEducationForm);
    });

    document.querySelectorAll(".deleteInfoForm").forEach((deleteButton) => {
        deleteButton.addEventListener("click", function () {
            this.closest(".educationFormLine").remove();
        });
    });

    educationFormsContainer.addEventListener("click", (event) => {
        if (event.target.closest(".deleteInfoForm")) {
            const formToDelete = event.target.closest(".educationFormLine");
            formToDelete.remove();
        }
    });

    const workExperienceContainer = document.querySelector(".workExperienceLine");
    const addWorkExperienceButton = document.querySelector(".workExperienceInfoForm .addInfoForm");

    addWorkExperienceButton.addEventListener("click", () => {
        const newWorkExperience = document.createElement("div");
        newWorkExperience.classList.add("workExperienceLine");

        newWorkExperience.innerHTML = `
            <div class="form-items">
                <div class="form-item-left">
                    <div class="form-item">
                        <label for="">İş yeri<sup>*</sup></label>
                        <input type="text" name="experience_company[]" placeholder="Müəssisənin adı">
                    </div>
                    <div class="form-item">
                        <label for="">Vəzifə<sup>*</sup></label>
                        <input type="text" name="position[]" placeholder="Vəzifənin  adı">
                    </div>
                </div>
                <div class="form-item-right">
                    <div class="form-item">
                        <label for="">Başlama tarixi<sup>*</sup></label>
                        <input type="date" name="experience_start_date[]" placeholder="Ay/İl">
                    </div>
                    <div class="form-item">
                        <label for="">Bitmə tarixi<sup>*</sup></label>
                        <input type="date" name="experience_end_date[]" placeholder="Ay/İl">
                    </div>
                </div>
            </div>
            <button class="deleteInfoForm">
                <img src="${assetBasePath}assets/images/trash.svg" alt="">
                Sil
            </button>
        `;

        newWorkExperience.querySelector(".deleteInfoForm").addEventListener("click", function () {
            newWorkExperience.remove();
        });

        workExperienceContainer.appendChild(newWorkExperience);
    });


    // Language Skills Section
    const languageSkillsContainer = document.querySelector(".languageSkillsInfoForm"); // Changed to the parent container
    const addLanguageSkillsButton = document.querySelector(".languageSkillsInfoForm .addInfoForm");

    addLanguageSkillsButton.addEventListener("click", () => {
        const newLanguageSkill = document.createElement("div");
        newLanguageSkill.classList.add("languageSkillsLine");

        newLanguageSkill.innerHTML = `
        <div class="form-items">
            <div class="form-item">
                <label for="">Dil<sup>*</sup></label>
                <select name="language[]">
                    <option value="">Seçin</option>
                    <option value="English">English</option>
                    <option value="Russian">Russian</option>
                    <option value="Spanish">Spanish</option>
                    <option value="Turkish">Turkish</option>
                </select>
            </div>
            <div class="form-item">
                <label for="">Bilik səviyyəniz<sup>*</sup></label>
                <select name="level[]">
                    <option value="">Seçin</option>
                    <option value="Advanced">Advanced</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Pre-Intermediate">Pre-Intermediate</option>
                    <option value="Beginner">Beginner</option>
                </select>
            </div>
        </div>
        <button class="deleteInfoForm">
            <img src="${assetBasePath}assets/images/trash.svg" alt="">
            Sil
        </button>
    `;

        newLanguageSkill.querySelector(".deleteInfoForm").addEventListener("click", function () {
            newLanguageSkill.remove();
        });

        languageSkillsContainer.insertBefore(newLanguageSkill, addLanguageSkillsButton);
        $(newLanguageSkill).find('select').niceSelect();
    });




    // Programs Information Section
    const programsContainer = document.querySelector(".programsLine");
    const addProgramButton = document.querySelector(".programsInfoForm .addInfoForm");

    addProgramButton.addEventListener("click", () => {
        const newProgram = document.createElement("div");
        newProgram.classList.add("programsLine");

        newProgram.innerHTML = `
            <div class="form-items">
                <div class="form-item">
                    <label for="">Proqramı seç<sup>*</sup></label>
                    <select name="program_name[]">
                        <option value="">Seçin</option>
                        <option value="Erasmus">Erasmus</option>
                        <option value="Erasmus">Erasmus</option>
                        <option value="Erasmus">Erasmus</option>
                        <option value="Erasmus">Erasmus</option>
                    </select>
                </div>
                <div class="form-items-right">
                    <div class="form-item">
                        <label for="">Ölkə<sup>*</sup></label>
                        <select name="country[]">
                            <option value="">Seçin</option>
                            <option value="Rusiya">Rusiya</option>
                            <option value="İsvecre">İsvecre</option>
                            <option value="Turkiye">Turkiye</option>
                            <option value="İtaliya">İtaliya</option>
                        </select>
                    </div>
                    <div class="form-item">
                        <label for="">Şəhər<sup>*</sup></label>
                        <select name="city[]">
                            <option value="">Seçin</option>
                            <option value="Moskva">Moskva</option>
                            <option value="Istanbul">İstanbul</option>
                            <option value="Milan">Milan</option>
                            <option value="Zurih">Zurih</option>
                        </select>
                    </div>
                    <div class="form-item">
                        <label for="">Müqavilənin başlayacağı tarix<sup>*</sup></label>
                        <input name="program_date[]" type="date" placeholder="Gün/Ay/İl" class="datepicker">
                    </div>
                </div>
            </div>
            <button class="deleteInfoForm">
                <img src="${assetBasePath}assets/images/trash.svg" alt="">
                Sil
            </button>
        `;

        newProgram.querySelector(".deleteInfoForm").addEventListener("click", function () {
            newProgram.remove();
        });

        programsContainer.appendChild(newProgram);
        $(programsContainer).find('select').niceSelect();
    });
});
